import { useAnimation } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import {faShoppingCart} from '@fortawesome/free-solid-svg-icons';
import { CartService } from '../services/cart-service/cart.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  userType
  myCart = this.cs.myCart
  faShoppingCart = faShoppingCart
  constructor(private us: UserService, private cs: CartService) { }

  ngOnInit(): void {
    this.userType = this.us.usertype
    console.log(this.userType)
  }

}
