import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  myCart = []
  items = 0;
  constructor() { 
    sessionStorage.setItem("cart", JSON.stringify(this.myCart))
  }


  addItem(newItem){
    const itemInCart = this.myCart.findIndex(x =>
      x.item == newItem
    )
    if(itemInCart === -1){
      this.myCart.push({
        item: newItem,
        qty: 1
      })
    }
    else{
      var quantity = this.myCart[itemInCart].qty
      quantity++
      this.myCart[itemInCart] = {
        item: newItem,
        qty: quantity
      }
    }
  }
}
