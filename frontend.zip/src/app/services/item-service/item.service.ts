import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  

  constructor(private http: HttpClient) { }
  getItems(): Promise<any>{
    return new Promise((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)
      this.http.get<any>(`http://54.157.6.158:3000/api/getitems`).subscribe(data =>{
        if(data !== 'Error'){
          var test = data
          res(test)
        }
        else
          res(false)
      })
    })
  }
  deleteItem(name): Promise<string>{
    return new Promise<string>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)
      this.http.post<any>(`http://54.157.6.158:3000/api/deleteitem/${name}`, {}).subscribe(data =>{
        res(data)
      })
      
    })
  }
  createItem(name, price, desc): Promise<string>{
    return new Promise<string>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)

      this.http.post<any>(`http://54.157.6.158:3000/api/additem`, {name: name, price: price,description: desc}).subscribe(data =>{
        res(data)
      })
      
    })
  }
  updateItem(name, price, desc): Promise<string>{
    console.log(name, price, desc)
    return new Promise<string>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)

      this.http.put<any>(`http://54.157.6.158:3000/api/updateitem/`, {name: name, price: price,description: desc}).subscribe(data =>{
        res(data)
      })
      
    })
  }

}
