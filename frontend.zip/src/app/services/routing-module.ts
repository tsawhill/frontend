import { RouterModule } from '@angular/router';
import { AddItemComponent } from '../add-item/add-item.component';
import { AddUserComponent } from '../add-user/add-user.component';
import { CartComponent } from '../cart/cart.component';
import { DeleteItemComponent } from '../delete-item/delete-item.component';
import { DeleteUserComponent } from '../delete-user/delete-user.component';
import { LandingpageComponent } from '../landingpage/landingpage.component';
import { LoginComponent } from '../login/login.component';
import { RegisterComponent } from '../register/register.component';
import { UpdateItemComponent } from '../update-item/update-item.component';
import { UpdateUserComponent } from '../update-user/update-user.component';


export const MyRouting = RouterModule.forRoot([
    {path: 'login', component: LoginComponent},
    {path: 'landingpage', component: LandingpageComponent},
    {path: 'cart', component: CartComponent},
    {path: 'register', component: RegisterComponent},
    {path: 'createuser', component: AddUserComponent},
    {path: 'updateuser', component: UpdateUserComponent},
    {path: 'deleteuser', component: DeleteUserComponent},
    {path: 'createitem', component: AddItemComponent},
    {path: 'updateitem', component: UpdateItemComponent},
    {path: 'deleteitem', component: DeleteItemComponent},
    {path:'', redirectTo:'/login',pathMatch: 'full'}

])