import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  myWishlist = []

  constructor() { 
    sessionStorage.setItem("wishlist", JSON.stringify(this.myWishlist))
  }


  addItem(newItem){
    const iteminWishlist = this.myWishlist.findIndex(x =>
      x.item == newItem
    )
    if(iteminWishlist === -1){
      this.myWishlist.push({
        item: newItem,
        qty: 1
      })
    }
  }
}
