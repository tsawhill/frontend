import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from '../services/item-service/item.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {
  myForm: FormGroup
  uname: FormControl
  userType = ''
  message = ''
  users = []
  constructor(private is: ItemService, private us: UserService, private r: Router) { }

  ngOnInit(): void {
    this.createForm()

    if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])


    this.us.getUsers().then(res=>{
      this.users = res      
    })     
  }

  createForm(){
    this.myForm = new FormGroup({
      uname: new FormControl(),
    })
  }

  public trackItem (index, item) {
    return item.trackId;
  }

  deleteUser(){
    console.log(this.myForm.value.uname)
   this.us.deleteUser(this.myForm.value.uname).then(result=>{
      this.message = result
    })
    this.us.getUsers().then(res=>{
      this.users = res      
    })
  }
}
