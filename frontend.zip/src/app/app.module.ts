import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MyRouting } from './services/routing-module';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AddItemComponent } from './add-item/add-item.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { UpdateItemComponent } from './update-item/update-item.component';
import { DeleteUserComponent } from './delete-user/delete-user.component';
import { DeleteItemComponent } from './delete-item/delete-item.component';
import { CartComponent } from './cart/cart.component';
import { NavbarComponent } from './navbar/navbar.component';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RegisterComponent } from './register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LandingpageComponent,
    AddUserComponent,
    AddItemComponent,
    UpdateUserComponent,
    UpdateItemComponent,
    DeleteUserComponent,
    DeleteItemComponent,
    CartComponent,
    NavbarComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MyRouting,
    ReactiveFormsModule,
    HttpClientModule,
    FontAwesomeModule,
    BrowserAnimationsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
